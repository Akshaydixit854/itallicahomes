@extends('ui.layouts.app')

@section('custom-css')

    {{ Html::style('ui/css/bootstrap.min.css') }}
    {{ Html::style('ui/css/styles.css') }}
    {{ Html::style('ui/css/responsive.css') }}
    {{ Html::style('ui/css/owl.carousel.min.css') }}
    {{ Html::style('ui/css/custom.css') }}
    <link rel="icon" href={{asset("ui/images/favicon.png")}} sizes="16x16" type="image/png">

@endsection

@section('custom-js')
    {{ Html::script('ui/js/jquery-library.js') }}
    {{ Html::script('ui/js/popper.min.js') }}
    {{ Html::script('ui/js/bootstrap.min.js') }}
    {{ Html::script('ui/js/auto-search.js') }}
    {{ Html::script('ui/js/owl.carousel.min.js') }}

    <!-- Testiminail Js Start -->
    <script>
        // Testiminail Start
        $(document).ready(function(){
            $("#testimonial-slider").owlCarousel({
                items:1,
                itemsDesktop:[1000,1],
                itemsDesktopSmall:[979,1],
                itemsTablet:[768,1],
                pagination:false,
                navigation:true,
                navigationText:["",""],
                autoPlay:true
            });
        });
        // Testiminail End
        // Responsive Menu  Start
        $(document).on('ready', function() {
            $( ".menu-list li ul" ).before( "<i class='sub-menu-icon'> &#xf0dd; </i>" );
            $('#menuBtn').click(function(){
                $('#menuBtn').toggleClass('open');
                $('.menu-list').toggleClass('menuvisible');
            });
            $(".menu-list li i").click(function(e) {
                $(this).next("ul").slideToggle();
            });
        });
        // Responsive Menu  Start
    </script>
@endsection

@section('content')
    <!-- Banner Section Start -->
    <div class="wrapper">
        <div class="about-page-banner">
            <img src={{asset("ui/images/About-banner.png")}} alt="about" />
        </div>
    </div>
    <!-- Banner Section End -->
    <!-- About Us Start -->
    <div class="wrapper">
        <div class="about-us-text-wrapper">
            <div class="main-container-wrapper">
                <span class="main-heading">About Italica<p>In 1986 we got to know by chance and learnt to love Tuscany. In the search for new houses and flats for you</p></span>
                <div class="wrapper">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="about-us-content">
                                <p>We often stop during our trips to the various regions and breathe Tuscany  with its beauty changing every day and its numerous scents and aromas caressing our senses. Tuscany is like the sea different every day and simply breath taking.</p>
                                <p>We were particularly struck by the areas around Volterra. And in Versilia mainly by the hills around Montignoso. Here one is surrounded by pinewoods, chestnut-trees and the sea, whose sound can be often heard despite the distance. When the  weather is fine, one can even see the Elba island and Cinque Terre.</p>
                            </div>
                            <em class="content_tag_line">Who better than us can take you through Atlanta Falcons Jerseys this region, that we know so well.</em>
                            <div class="about-us-content">
                                <p>Do you wish to buy a house or an apartment? We will help you from the first step to the delivery of the new  house.
                                    Besides helping you personally in the drawing  up of the contract, we also give you the possibility of a contact locally. We will not leave you alone once you get there, but we will keep on assisting you through our branch in Versilia. In this way we can suggest you Trattoria known only to local, give you information on local events and help you with petty or serious problems. We will certainly find the right environment for you, as  we know even the most secluded places  in Tuscany and we are always informed on the latest news.</p>
                                <p>Do you prefer to buy a Villa  or spend your holiday in another region of Italy? Make your requests and we will be pleased to help you also in this case.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us End -->
    <!-- Services Start -->
    <div class="wrapper">
        <div class="services-banner">
            <div class="main-container-wrapper">
                <div class="wrapper">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="service-list-wrapper">
                                <span><img src={{asset("ui/images/skyline.png")}} alt="skyline"/></span>
                                <abbr>REAL ESTATE APPRAISAL</abbr>
                                <p>We will be pleased to advise you in respect of any question concerning  selling or letting of italian properties</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-list-wrapper">
                                <span><img src={{asset("ui/images/lifebuoy.png")}} alt="lifebuoy"/></span>
                                <abbr>FRIENDLY CUSTOMER SUPPORT</abbr>
                                <p>Our success stems from our Passion for real estate. And Italy.</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-list-wrapper">
                                <span><img src={{asset("ui/images/premium-badge.png")}} alt="premium-badge"/></span>
                                <abbr>PREMIUM QUALITY</abbr>
                                <p>Italica is successfully handling italian exclusive properties for over 20 years</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="service-list-wrapper">
                                <span><img src={{asset("ui/images/stopwatch.png")}} alt="stopwatch"></span>
                                <abbr>WE SAVE YOUR TIME</abbr>
                                <p>Italica´s  portfolio includes high-class villas, exclusive apartments, country houses, winery, hotels and  luxury property...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Services End -->
    <!-- About Us Content Start -->
    <div class="wrapper">
        <div class="about-us-text-wrapper">
            <div class="main-container-wrapper">
                <span class="main-heading main-heading1"><p>Do you prefer to buy a villa or spend your holiday in another region of Italy? Make your requests and we will be pleased to help you also in this case.</p></span>
                <div class="about-us-content-btn">
                    <a href="/contact">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us Content End -->
    <!-- Testimonials Start -->
    <div class="wrapper">
        <div class="testimonials-wrapper">
            <div class="main-container-wrapper">
                <span class="testimonials-heading main-heading1">Testimonials</span>
                <div class="wrapper">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="testimonial-slider" class="owl-carousel">
                                @foreach($testimonials as $testimonial)
                                <div class="testimonial">
                                    <div class="pic">
                                        <img src="images/testimonial-covers/{{$testimonial->cover_image}}" alt="">
                                    </div>
                                    <p class="description">
                                        “ {{$testimonial->description}}”
                                    </p>
                                    <h3 class="title">- {{$testimonial->name}} -
                                    </h3>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonials End -->
@endsection
