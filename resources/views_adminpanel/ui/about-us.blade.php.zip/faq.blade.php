@extends('ui.layouts.app')

@section('custom-css')
    <link rel="icon" href={{asset("ui/images/favicon.png")}} sizes="16x16" type="image/png">
    <!-- Bootstrap CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/bootstrap.min.css")}}>
    <!-- Bootstrap CSS End -->
    <!-- Custom CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/styles.css")}}>
    <link rel="stylesheet" href={{asset("ui/css/responsive.css")}}>
    <!-- Custom CSS End -->
@endsection
@if(Session::has('message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
@endif

@section('content')
    <!-- Banner Section Start -->
    <div class="wrapper">
        <div class="about-page-banner">
            <img src={{asset("ui/images/destination_banner.jpg")}} alt="banner"/>
        </div>
    </div>
    <!-- Banner Section End -->
    <!-- FAQ Start -->
    <div class="wrapper">
        <div class="about-us-text-wrapper remove-box-shadow">
            <div class="main-container-wrapper">
                <span class="main-heading">Frequently Asked Questions</span>
                <div class="all-question-section">
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="faq-list-block">
                                <li c>
                                    <a class="{{ $check == 'questions' ? 'active' : '' }}" href="/faq/0"><i>&#xf27a;</i>All Question</a>
                                </li>
                                <li >
                                    <a  class="{{ $check == 'agents' ? 'active' : '' }}" href="/faq/1"><i>&#xf015;</i>Agents</a>
                                </li>
                                <li>
                                    <a class="show-all" href="javascript:void(0)">Expand all</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="faq-querstion-form-wrapper">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="wrapper">
                                <div id="accordion" class="accordion">
                                    @foreach($faqs as $id => $faq)
                                    <div class="wrapper">
                                        <div class="card-header collapsed custom-card-header " data-toggle="collapse"
                                             href="#collapse{{$id}}">
                                            <a class="card-title custom-card-title">
                                                {{$faq->question}}
                                            </a>
                                        </div>
                                        <div id="collapse{{$id}}" class=" collapse custom-collapse-content wrapper"
                                             data-parent="#accordion">
                                            <p>{{$faq->answer}}</p>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <form id="form_validation" method="POST" action={{route("contact-faq")}} enctype="multipart/form-data">
                                {{ csrf_field() }}
                            <div class="faq-form-block">
                                <div class="faq-pic-section">
                                    <span></span>
                                </div>
                                <div class="faq-form-field">
                                    <span>Do you have questions?</span>
                                    <ul class="faq-query-form">
                                        <li>
                                            <span>Name</span>
                                            <abbr>
                                                <input name="name" class="name" type="text">
                                            </abbr>
                                        </li>
                                        <li>
                                            <span>Email</span>
                                            <abbr>
                                                <input name="email" class="email" type="text">
                                            </abbr>
                                        </li>
                                        <li>
                                            <span>Your Question</span>
                                            <abbr>
                                                <textarea class="question" name="question"></textarea>
                                            </abbr>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="faq-form-btn">
                                <button id="js-contact-us" type="submit">Send</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FAQ Start End -->
@endsection


@section('custom-js')
    <!-- Bootstrap JS Start -->
    <script src={{asset("ui/js/jquery-library.js")}}></script>
    <script src={{asset("ui/js/popper.min.js")}}></script>
    <script src={{asset("ui/js/bootstrap.min.js")}}></script>
    <script>
        // Responsive Menu  Start
        $(document).on('ready', function () {
            $('.custom-collapse-content').removeClass('show');
            $('.show-all').click(function(){
                if($('.custom-collapse-content').hasClass('show')){
                    $('.custom-collapse-content').removeClass('show');
                }else{
                    $('.custom-collapse-content').addClass('show');
                }
            });
            $(".menu-list li ul").before("<i class='sub-menu-icon'> &#xf0dd; </i>");
            $('#menuBtn').click(function () {
                $('#menuBtn').toggleClass('open');
                $('.menu-list').toggleClass('menuvisible');
            });
            $(".menu-list li i").click(function (e) {
                $(this).next("ul").slideToggle();
            });

            $('#js-contact-us').click(function(){
                if($('.error').length > 0){
                    $('.error').remove();
                }
                var name = $('.name').val();
                var email = $('.email').val();
                var question = $('.question').val();
                if(name.trim() == '' || email.trim() == '' || question.trim() == ''){
                    if(name.trim() == ''){
                        $('.name').after('<p class="error">Required</p>');
                    }
                    if(email.trim() == ''){
                        $('.email').after('<p class="error">Required</p>');
                    }
                    if(question.trim() == ''){
                        $('.question').after('<p class="error">Required</p>');
                    }
                    return false;
                }
                if(!validateEmail(email)){
                    $('.email').after('<p class="error">Invalid email</p>');
                    return false;
                }
            });


        });
        // Responsive Menu  Start
    </script>
@endsection
