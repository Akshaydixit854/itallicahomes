@extends('ui.layouts.app')

@section('custom-css')
    <link rel="icon" href={{asset("ui/images/favicon.png")}})}} sizes="16x16" type="image/png">
    <!-- Bootstrap CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/bootstrap.min.css")}}>
    <!-- Bootstrap CSS End -->
    <!-- Custom CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/styles.css")}}>
    <link rel="stylesheet" href={{asset("ui/css/responsive.css")}}>
    <!-- Custom CSS End -->
    <!-- Autosearch CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/autosearch.css")}}>

    <link rel="stylesheet" href={{asset("ui/css/owl.carousel.min.css")}}>

    <link rel="stylesheet" href={{asset("ui/css/custom.css")}}>
    <!-- Autosearch CSS End -->
    <!-- Properties Slider Start -->
    <link rel="stylesheet" href={{asset("ui/css/thumbnail-slider.css")}} type="text/css" media="screen" />
    <!-- Properties Slider End -->
    <!-- Price range Slider Start -->
    {{-- <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.3/themes/hot-sneaks/jquery-ui.css" />
	<script src="http://code.jquery.com/jquery-2.1.3.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script> --}}
    <!-- Properties Slider End -->


@endsection
@include('cookieConsent::index')
@if(Session::has('message'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
@endif
@section('content')
    <!-- Banner Section Start -->
    <div class="wrapper">
        <form id="form_validation" method="POST" action="{{ url('search') }}">
         {{ csrf_field() }}
        <div class="search-property-bg-img">
            <div class="main-container-wrapper">
                {{-- <input type="text" name="min_price" value="@if($request->min_price) {{$request->min_price}} @else {{0}} @endif" id="min" readonly>
                <input type="text" name="max_price" value="@if($request->max_price) {{$request->max_price}} @else {{1000}} @endif" id="max" readonly>
                <div id="mySlider"></div> --}}

                <div class="properties-searchbar-block">
                          <span>
                              <select class="form-control" name="property_offer">
                                <option value="" selected disabled>Please select</option>
                                  @foreach($propertyOffers as $propertyOffer)
                                      <option value={{$propertyOffer->id}}  @if($request->property_offer == $propertyOffer->id) {{'selected'}} @endif>For {{$propertyOffer->offer_name}}</option>
                                  @endforeach
                              </select>
                          </span>
                    <abbr>
                        <input type="text" name="q" value="@if(trim($request->q)) {{$request->q}} @endif" placeholder="Keyword or Listing ID" id="autosearchbar"/>
                        {{-- <a href = "#">&#xf002</a> --}}
                    </abbr>
                    <em>
                        <button class="ser-btn" type="submit" href="#">Submit</button>
                        {{-- <input type="submit" value="Search"> --}}
                    </em>
                </div>
                <ul class="properties-filter-more">
                    <li>
                        <select class="form-control" name="region_id">
                            <option value="" selected disabled>Region</option>
                            @foreach($regions as $region)
                                <option value={{$region->id}} @if($request->region_id == $region->id) {{'selected'}} @endif >{{$region->region_name}}</option>
                            @endforeach
                        </select>
                    </li>
                    {{-- <li>
                        <select class="form-control" name="location_id">
                            <option value="" selected disabled >Province/State</option>
                            @foreach($locations as $location)
                                <option value={{$location['location_id']}}  @if($request->location_id == $location['location_id']) {{'selected'}} @endif>{{$location['location_name']}}</option>
                            @endforeach
                        </select>
                    </li> --}}

                    <li>
                        <select class="form-control" name="property_type_id">
                            <option value="" selected disabled>Type</option>
                            @foreach($propertyTypes as $propertyType)
                                <option value={{$propertyType->id}}  @if($request->property_type_id == $propertyType->id) {{'selected'}} @endif>{{$propertyType->type_name}}</option>
                            @endforeach
                        </select>
                    </li>
                    <li>
                        <select class="form-control" name="property_condition_id">
                            <option value="" selected disabled>Condition</option>
                            @foreach($conditions as $condition)
                                <option value={{$condition->id}} @if($request->property_condition_id == $condition->id) {{'selected'}} @endif>{{$condition->condition_display_name}}</option>
                            @endforeach
                        </select>
                    </li>
                    <li>
                        <select class="form-control" name="price_range_id">
                            <option value="" selected disabled>Price</option>
                            <option value="1">$1K to $10K</option>
                            <option value="2">$11K to $50K</option>
                            <option value="3">$51K to $1M</option>
                        </select>
                    </li>
                </ul>
            </div>
        </div>
        <div class="properties-more-advance-filter-main">
            <div class="properties-more-advance-filter">
                <div class="main-container-wrapper">
                    <div class="wrapper">
                        <!-- <ul class="search-map-filter">
                           <li class="">
                             <a href = "#"><i>&#xf279;</i>Map View</a>
                           </li>
                           <li>
                             <a href = "#"><i>&#xf00b;</i>List View</a>
                           </li>
                        </ul> -->
                        <!-- <ul id = "myTab" class = "nav nav-tabs">
                           <li class = "active">
                              <a href = "#home" data-toggle = "tab">
                                 Tutorial Point Home
                              </a>
                           </li>
                           <li><a href = "#ios" data-toggle = "tab">iOS</a></li>
                        </ul> -->


                        <ul class="search-bed-filter">
                            <li>
                                <select class="form-control" name="beds">
                                    <option value="" selected disabled>Beds</option>
                                    @for($i=1; $i<=10; $i++ )
                                    <option value={{$i}} @if($request->beds == $i) {{'selected'}} @endif>{{$i}}</option>
                                        @endfor
                                </select>
                            </li>
                            <li>
                                <select class="form-control" name="baths">
                                    <option value="" selected disabled>Bathrooms</option>
                                    @for($i=1; $i<=10; $i++ )
                                        <option value={{$i}} @if($request->baths == $i) {{'selected'}} @endif>{{$i}}</option>
                                    @endfor
                                </select>
                            </li>
                            <li>
                                <select class="form-control" name="default_plot_size">
                                    <option value="" selected disabled>Area</option>
                                    <option value="1-100" @if($request->default_plot_size == '1-100') {{'selected'}} @endif>1 - 100 Sq.ft</option>
                                    <option value="100-500" @if($request->default_plot_size == '100-500') {{'selected'}} @endif>100 - 500 Sq.ft</option>
                                    <option value="500-1000" @if($request->default_plot_size == '500-1000') {{'selected'}} @endif>500 - 1000 Sq.ft</option>
                                    <option value="1000-10000" @if($request->default_plot_size == '1000-10000') {{'selected'}} @endif>1000 - 10000 Sq.ft</option>
                                    <option value="10000-more" @if($request->default_plot_size == '10000-more') {{'selected'}} @endif>10000 - more Sq.ft</option>
                                </select>
                            </li>
                            <li>
                                <select class="form-control" name="destination_id">
                                    <option value="" selected disabled>Destinations</option>
                                    @foreach($destinations as $destination)
                                        <option value={{$destination->id}}  @if($request->destination_id == $destination->id) {{'selected'}} @endif>{{$destination->destination_name}}</option>
                                    @endforeach
                                </select>
                            </li>
                        </ul>
                        <ul class="search-newest-filter">
                            <li>
                                <select class="form-control" name="order">
                                    <option value="" selected disabled>Newest</option>
                                    <option value="asc" @if($request->order == 'asc') {{'selected'}} @endif>Property ASC</option>
                                    <option value="desc" @if($request->order == 'desc') {{'selected'}} @endif>Property DESC</option>
                                    <option value="price_asc" @if($request->order == 'price_asc') {{'selected'}} @endif>Price Low</option>
                                    <option value="price_desc" @if($request->order == 'price_desc') {{'selected'}} @endif>Price High</option>
                                </select>
                            </li>
                            <li><em class="filer-show-block show-all-filter"></em></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="">
           <div class="wrapper adv-filter-block">
               <div class="">
                 <div class="main-container-wrapper">
                   <div class="price-filter">
                       <span>Price</span>
                       <ul class="price-filter-adv">
                           <li>
                               <span>Min</span>
                               <abbr>
                                   <input type="text" name="min_price" class="min_price" value="@if($request->min_price) {{$request->min_price}} @else {{0}} @endif" placeholder="Min">
                               </abbr>
                           </li>
                           <li>
                               <span>Max</span>
                               <abbr>
                                   <input type="text" name="max_price" class="max_price" value="@if($request->max_price) {{$request->max_price}} @else {{0}} @endif" placeholder="Max">
                               </abbr>
                           </li>
                           <li>
                               <span>SQ.FT. min</span>
                               <abbr>
                                   <input type="text" name="min_sq_ft" class="min_sq_ft" value="@if($request->min_sq_ft) {{$request->min_sq_ft}} @else {{0}} @endif" placeholder="Min">
                               </abbr>
                           </li>
                           <li>
                               <span>SQ.FT. Max</span>
                               <abbr>
                                  <input type="text" name="max_sq_ft" class="max_sq_ft" value="@if($request->max_sq_ft) {{$request->max_sq_ft}} @else {{0}} @endif" placeholder="Max">
                               </abbr>
                           </li>
                       </ul>
                   </div>
                   <div class="price-filter">
                       <span>Location</span>
                       <ul class="location-filter-adv">
                           @foreach($default_areas as $area)
                               {{-- <li>
                                   <span>
                                     <input type="radio" value="{{$location['location_id']}}" id="location_{{$location['location_id']}}" name="location_id" @if($request->location_id == $location['location_id']) {{'checked'}} @endif>
                                     <label for="location_{{$location['location_id']}}">{{$location['location_name']}} <b>({{$location['total']}})</b></label>
                                   </span>
                               </li>--}}

                               <li>
                                 <span>
                                   <input type="radio" id="test{{$area['area_id']}}" name="area_id" value="{{$area['area_id']}}" @if($request->area_id == $area['area_id']) {{'checked'}} @endif>
                                   <label for="test{{$area['area_id']}}">{{$area['area_name']}} <b>({{$area['total']}})</b></label>
                                 </span>
                               </li>
                           @endforeach
                       </ul>
                   </div>
                   <div class="price-filter">
                       <span>Ameneties</span>
                       <ul class="facilities-filter-adv">
                           @foreach($amenities as $amenity)
                               <li>
                                   <span>
                                     <input type="checkbox" name="amenity_id[]" value="{{$amenity['id']}}" id="check_{{$amenity['id']}}"  @if(is_array($request->amenity_id) && in_array($amenity['id'],$request->amenity_id)) {{'checked'}} @endif/>
                                     <label for="check_{{$amenity['id']}}">{{$amenity['amenities_display_name']}} <b>({{$amenity['total']}})</b></label>
                                   </span>
                               </li>
                           @endforeach
                       </ul>
                   </div>
                   <div class="text-center">
                        <a href="javascript:void(0)" class="refine-search">Update Search</a>
                    </div>
                 </div>
               </div>
           </div>

        </div>
    </div>
</form>
    <!-- Banner Section End -->
    <!-- Properties Heading Start -->
    <div class="wrapper">
        <div class="about-us-text-wrapper properties-text-wrapper remove-shadow-section">
            <div class="main-container-wrapper">
                <span class="main-heading">Properties<p>We Found <abbr>{{count($properties)}}</abbr>matches</p></span>
            </div>
        </div>
    </div>
    <!-- Properties Heading End -->
    <!-- Properties List Start -->
    <div class="wrapper">
        <div class="properties-view-main">
            <div class="wrapper">

                <div class="row tab-content panel-container">
                    <div class="col-md-6 res-properties-view panel-left" >
                        @php
                            $fills = 0;
                            $property_markers = array();
                        @endphp
                        @foreach ($properties as $property)
                            @php
                                $property_markers[$fills]['name'] = $property->name;
                                $property_markers[$fills]['latitude'] = $property->property_location_latitude;
                                $property_markers[$fills]['longitude'] = $property->property_location_longitude;
                                $property_markers[$fills]['image'] = asset("/images/cover-images/".$property->cover_image_name);
                                $property_markers[$fills]['url'] = '/properties/'.$property->id;
                                $property_markers[$fills]['id'] = $property->id;
                                $property_markers[$fills]['price'] = number_format($property->price , 0, ',', '.');
                                $property_markers[$fills]['fav'] = (new \App\Services\PropertyService)->checkFav($property->id);
                                $fills++
                            @endphp
                            <div class="col-md-6 properties-list-block">
                                <div class="properties-list-wrapper properties-inner-list">
                                    <div class="properties-pic-section">
                                        <span><img src={{asset("/images/cover-images/".$property->cover_image_name)}}></span>
                                        <ul class="properties-list">
                                            <li>
                                                <span>{{$property->beds}}</span>
                                                <abbr>Beds</abbr>
                                                <em>&#xf236;</em>
                                            </li>
                                            <li>
                                                <span>{{$property->baths}}</span>
                                                <abbr>Baths</abbr>
                                                <em>&#xf2cd;</em>
                                            </li>
                                            <li>
                                                <span>{{$fills}}</span>
                                                <abbr>Kitchen</abbr>
                                                <em>&#xf0f5;</em>
                                            </li>
                                        </ul>
                                        <abbr class="red-tag" style="background: {{$property->type->ui_color}}">{{$property->type->type_name}}</abbr>
                                    </div>
                                    <div class="properties-name">
                                        @if(\Lang::has('property.property_title_'.$property->id))
                                            <span><em>{{(new \App\Services\PropertyService)->truncate(trans('property.property_title_'.$property->id)) }}</em><i><a href="/favourite/{{$property->id}}">{{(new \App\Services\PropertyService)->checkFav($property->id) }}</a></i></span>
                                        @else
                                            <span><em>{{(new \App\Services\PropertyService)->truncate($property->name)}}</em><i><a href="/favourite/{{$property->id}}">{{(new \App\Services\PropertyService)->checkFav($property->id) }}</a></i></span>
                                        @endif
                                        <abbr class="properties-loction"><em>&#xf041;</em>{{(new \App\Services\PropertyService)->getRegion($property->region_id) }}</abbr>
                                        <i class="properties-price-doller">{{number_format($property->price , 0, ',', '.')}}</i>
                                    </div>
                                    <div class="properties-decription">
                                        @if(\Lang::has('property.property_short_desc_'.$property->id))
                                            {{(new \App\Services\PropertyService)->truncate(trans('property.property_short_desc_'.$property->id),150) }}
                                        @else
                                            {{(new \App\Services\PropertyService)->truncate($property->short_description,150) }}
                                        @endif
                                    </div>
                                    <a href="/properties/{{$property->id}}" class="properties-link">Read More</a>
                                </div>
                            </div>

                            <div class="popupslider modal fade" id="quick-map-modal-{{$property->id}}" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <!-- Quick Map View Left Starts -->
                                                <div class="col-md-6">
                                                    <div class="demo">
                                                        <ul id="" class="lightSlider">
                                                            @foreach($property->property_image_gallery as $gallery_image)
                                                                <li class="gal-img" data-thumb={{asset("/images/cover-images/".$gallery_image->image)}}>
                                                                    <img src={{asset("/images/cover-images/".$gallery_image->image)}} />
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                                <!-- Quick Map View Left Ends -->
                                                <!-- Quick Map View Right Starts -->
                                                <div class="col-md-6">
                                                    <div class="quick-map-right">
                                                        <div class="map-det-head">
                                                            <h3 class="map-det-tit">
                                                                {{$property->name}}
                                                                @if(\Lang::has('property.property_title_'.$property->id))
                                                                    {{trans('property.property_title_'.$property->id)}}
                                                                @else
                                                                    {{$property->name}}
                                                                @endif

                                                            </h3>
                                                            <p class="map-det-txt">Property ID: {{$property->property_id}}</p>
                                                        </div>
                                                        <div class="pos-rel">
                                                            <div class="txt-overlay"></div>
                                                            <p class="map-view-main-txt">
                                                                @if(\Lang::has('property.property_short_desc_'.$property->id))
                                                                    {{(new \App\Services\PropertyService)->truncate(trans('property.property_short_desc_'.$property->id),150) }}
                                                                @else
                                                                    {{(new \App\Services\PropertyService)->truncate($property->short_description,150) }}
                                                                @endif
                                                            </p>
                                                        </div>
                                                        <ul class="properties-list12">
                                                            <li>
                                                                <span>{{$property->beds}}</span>
                                                                <abbr>Beds</abbr>
                                                                <em></em>
                                                            </li>
                                                            <li>
                                                                <span>{{$property->baths}}</span>
                                                                <abbr>Baths</abbr>
                                                                <em></em>
                                                            </li>
                                                            <li>
                                                                <span>1</span>
                                                                <abbr>Kitchen</abbr>
                                                                <em></em>
                                                            </li>
                                                        </ul>
                                                        <div>
                                                            <h2 class="map-rate">From {{number_format($property->price , 0, ',', '.')}} $</h2>
                                                            <a href="/favourite/{{$property->id}}" class="map-fav">{{(new \App\Services\PropertyService)->checkFavTxt($property->id) }}</a>
                                                            <div>
                                                                <a href="/properties/{{$property->id}}" class="map-read-more cmn-btn red-bg">Read more</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Quick Map View Right Starts -->
                                            </div>
                                        </div>
                                        <div class="modal-footer custom-model-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                        @if ($fills < count($properties))
                            <div class="properties-view-all">
                                <a href="#">View More</a>
                            </div>
                        @endif

                    </div>
                    <div class="properties-map-section panel-right">
                        <span class="splitter map-arrow-btn">&#xf104;<i>&#xf105;</i></span>
                        <div class="property-view-map">
                            <!-- <div style="width:100%;height:100%;"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d5297.447035450058!2d13.3855753!3d48.4042525!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4774435f60d1e2b7%3A0x3714d97cce651b72!2sSch%C3%B6merweg+14%2C+94060+Pocking%2C+Germany!5e0!3m2!1sen!2sin!4v1537985697608" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe></div> -->
                            <div id="map" style="width:100%;height:1020px"></div>
                        </div>
                    </div>
                    <!-- Map Pointer Hover Start -->
                    <!-- <div class="map-hover-view">
                       <div class="properties-list-wrapper properties-map-inner-list">
                           <div class="properties-pic-section">
                              <span><img src="images/hotol.png"></span>
                           </div>
                           <div class="properties-name">
                              <span><em>Unique Seafront Villa in The</em><i>&#xf006;</i></span>
                              <abbr class="properties-loction"><em>&#xf041;</em>Laglio, Como, Italy</abbr>
                              <i class="properties-price-doller">12540</i>
                           </div>
                           <div class="map-hover-properties-btn">
                             <a href="#" data-toggle="modal" data-target="#view-properties-details" class="quick-btn">Quick View</a>
                             <a href="#" class="property-btn">Go to Property</a>
                           </div>
                        </div>
                    </div> -->
                    <!-- Map Pointer Hover End -->
                </div>
            </div>
        </div>
    </div>

    <!-- Properties List End -->
@endsection

@section('custom-js')
    <!-- Bootstrap JS Start -->
    <script src={{asset("ui/js/jquery-library.js")}}></script>
    <script src={{asset("ui/js/popper.min.js")}}></script>
    <script src={{asset("ui/js/bootstrap.min.js")}}></script>
    <script src={{asset("ui/js/auto-search.js")}}></script>
    <script src={{asset("ui/js/owl.carousel.min.js")}}></script>
    <script src={{asset("ui/js/thumbnail-slider.js")}}></script>
    <script src={{asset("ui/js/jquery-resizable.js")}}></script>
    <script src={{asset("ui/js/price_range_script.js")}}></script>
    <script src={{asset("ui/js/jquery.matchHeight-min.js")}}></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAlVWqoyW0m38zUFtbQ88f3h_kYYQtc9g0&callback=initMap" type="text/javascript"></script>
    {{-- <script>

        $(document).ready(function() {
          //   $( "#mySlider" ).slider({
          //     range: true,
          //     min: 0,
          //     max: 999,
          //     values: [ {{$request->has('min_price') ? $request->min_price : 0}}, {{$request->has('max_price') ? $request->max_price : 1000}} ],
          //     slide: function( event, ui ) {
          //         $("#min").val(ui.values[0]);
          //         $("#max").val(ui.values[1]);
          //     }
          // });
        });
    </script> --}}
    <script>
    $(document).ready(function() {
        var count = 0
        $('.popupslider').on('shown.bs.modal', function() {
            var x = document.getElementsByClassName("lSGallery");
            console.log(x);
            for(var i = 0;i < x.length;i++){
                if(i != 0){
                    x[i].remove();
                }
            }
            //if (count === 1) return;
            //$('#image-gallery').addClass('cS-hidden');
            $('.lightSlider').lightSlider({
                gallery: true,
                item: 1,
                thumbItem: 4,
                slideMargin: 0,
                speed: 500,
                auto: true,
                loop: true,
                onSliderLoad: function() {
                    //$('#image-gallery').removeClass('cS-hidden');
                }
            });
            count++;
        });
    });
    </script>
    <?php
        $t = json_encode($property_markers,true);
    ?>
    <script>

        var l = '<?php echo $t;?>';
        var locations = JSON.parse(l.replace(/^"/,""));
        //Initialize and add the map
        function initMap() {
            // The location of Uluru
            // var uluru = {lat: -25.344, lng: 131.036};
            // // The map, centered at Uluru
            //
            // var map = new google.maps.Map(
            //     document.getElementById('map'), {
            //         zoom: 12,
            //         center: uluru,
            //         mapTypeControl: false,
            //         zoomControl: true,
            //     });
            // // The marker, positioned at Uluru
            // var marker = new google.maps.Marker({position: uluru, map: map});

            // var locations = [
            //   ['Bondi Beach', 42.424114,  11.631095, 4],
            //   ['Coogee Beach', 41.879040, 41.879040 , 2],
            //   ['Cronulla Beach', 41.942802, 12.774399, 3],
            //   ['Manly Beach', 41.886131, 12.485133, 2],
            //   ['Manly Beach', 41.886131, 12.485133, 2],
            // ];


            var map = new google.maps.Map(document.getElementById('map'), {
              zoom: 8,
              center: new google.maps.LatLng(41.8719, 12.5674),
              mapTypeId: google.maps.MapTypeId.ROADMAP
            });

            var infowindow = new google.maps.InfoWindow();

            var marker, i;
            var obj = {};
            for (i = 0; i < locations.length; i++) {
              marker = new google.maps.Marker({
                position: new google.maps.LatLng(locations[i]['latitude'], locations[i]['longitude']),
                map: map
              });
              con = '';
              con = '<div class="map-hover-view"><div class="properties-list-wrapper properties-map-inner-list"><div class="properties-pic-section"><span><img src="'+locations[i]['image']+'"></span></div>';
              con+='<div class="properties-name"><span><em>'+locations[i]['name']+'</em><i>'+'<a href="/favourite/'+locations[i]['id']+'">'+locations[i]['fav']+'</a></i></span><abbr class="properties-loction"><em>&#xf041;</em>Laglio, Como, Italy</abbr>';
              con+='<i class="properties-price-doller">'+locations[i]['price']+'</i></div> <div class="map-hover-properties-btn"><a href="#" onclick="sowjin()" data-toggle="modal" data-target="#quick-map-modal-'+locations[i]['id']+'" class="quick-btn">Quick View</a>';
              con+='<a href="'+locations[i]['url']+'" class="property-btn">Go to Property</a></div></div></div>';
              obj['content'+i] = con;
              console.log(i);
              google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
                return function() {
                  infowindow.setContent(obj['content'+i]);
                  infowindow.open(map, marker);
                }
              })(marker, i));
            }
        }
    </script>
    <script type="text/javascript">

  </script>
    <script>
        $(".panel-left").resizable({
            handleSelector: ".splitter",
            resizeHeight: false,
            handles: 'e',
            distance:0,
            minWidth: 320
            // $('.panel-left').addClass('active');
            //(".panel-left").minWidth('500px');
        });

        // Section Resize JS
        // $(document).on('resize', function() {
        //     var $property = $('.panel-left');
        //     if(property < 480) {
        //         $('.panel-left').addClass('active');
        //     }
        // });
    </script>
    <!-- resizable Start -->
    <script>
        $(document).ready(function(){
            $('.adv-filter-block').toggle('hide');
            $('.price-location-adv-filter-wrapper').hide();
            $('.show-all-filter').on('click', function(event) {
                $('.adv-filter-block').toggle('show');
                if($('.filer-show-block').hasClass('close-pro-filter')){
                    $('.filer-show-block').removeClass('close-pro-filter');
                    $('.filer-show-block').addClass('show-all-filter');
                }else{
                    $('.filer-show-block').removeClass('show-all-filter');
                    $('.filer-show-block').addClass('close-pro-filter');
                }

            });
        });
         // Match Height
        $(function() {
            $('.equal-height').matchHeight({
                byRow: true,
                property: 'height'
            });
        });
        // Autosearch Start
        $( function() {
            var availableTags = [];
            $.ajax({
                url: '/properties/autocomplete',
                dataType: "JSON",
                type: "GET",
                success: function(data){
                    var properties = data.properties;
                    for(var i = 0;i < properties.length;i++){
                        availableTags.push(properties[i]['name']);
                        availableTags.push(properties[i]['property_id']);
                    }
                }
            });
            $( "#autosearchbar" ).autocomplete({
                source: availableTags,
            });
        } );
        // Autosearch End
        // $('#lightSlider').lightSlider({
        //     gallery: true,
        //     item: 1,
        //     loop: true,
        //     slideMargin: 0,
        //     thumbItem:8,
        //     auto:true
        // });
        $(".quick-btn").click(function() {
            $(window).resize();
            $(window).resize();
        });
    </script>
    <!-- Properties Slider End -->
    <script>
        // Responsive Menu  Start
        $(document).on('ready', function() {
            $( ".menu-list li ul" ).before( "<i class='sub-menu-icon'> &#xf0dd; </i>" );
            $('#menuBtn').click(function(){
                $('#menuBtn').toggleClass('open');
                $('.menu-list').toggleClass('menuvisible');
            });
            $(".menu-list li i").click(function(e) {
                $(this).next("ul").slideToggle();
            });

            $('.ser-btn').click(function(){
                if($('.error').length > 0){
                    $('.error').remove();
                }
                var min_value = $('.min_price').val();
                var max_value = $('.max_price').val();
                var min_sq = $('.min_sq_ft').val();
                var max_sq = $('.max_sq_ft').val();
                if(min_value > max_value || min_sq > max_sq){
                    if(min_value > max_value){
                        $('.min_price').after('<p class="error">Minimum price should not be greater than maximum price</p>');
                    }
                    if(min_sq > max_sq){

                        $('.min_sq_ft').after('<p class="error">Minimum sq.ft should not be greater than maximum sq.ft</p>');
                    }
                    return false;
                }
            });

            $('.refine-search').click(function(){
                $('#form_validation').submit();
            });
        });
        // Responsive Menu  Start
    </script>
@endsection
