<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Required meta tags Start -->
    <title>Italica</title>
    @yield('custom-css')
</head>
<body>
<div class="wrapper">
    <!-- Header Start -->
    <header>
        <div class="top-header-nav">
            <div class="main-container-wrapper">
                <div class="col-md-12">
                    <div class="top-header-menu">
                        <ul class="top-notice">
                            <li><a href="/myfavourite"><i>&#xf004;</i>Your Favorites Properties ({{(new \App\Services\PropertyService)->getFavCount()}})</a></li>
                            <li><a href="#">Rental Website</a></li>
                            <li><a href={{route('legal')}}>Legal Notice</a></li>
                            <li><a href={{route('terms')}}>Terms & Conditions</a></li>
                        </ul>
                        <ul class="top-social-icon">
                            <li><a href="https://www.facebook.com/italicahomes/"
                                   class="facebook-icon-color">&#xf082;</a></li>
                            <li><a href="https://plus.google.com/109250640606041825381" class="google-icon-color">&#xf0d4;</a></li>
                            <li><a href="https://twitter.com/livingartIT" class="twitter-icon-color">&#xf081;</a></li>
                        </ul>
                        <ul class="language-list">


                            <li ><a href="/locale/en" style="@if(Config::get('app.locale') == 'en') {{'color:green'}} @endif"><img src={{asset("/ui/images/english.png")}}>English</a></li>
                            <li><a href="/locale/it" style="@if(Config::get('app.locale') == 'it') {{'color:green'}} @endif"><img src={{asset("/ui/images/italian.png")}}>Italian</a></li>
                            <li><a href="/locale/de" style="@if(Config::get('app.locale') == 'de') {{'color:green'}} @endif"><img src={{asset("/ui/images/german.png")}}>German</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-menu-wrapper">
            <div class="main-container-wrapper">
                <div class="row">
                    <div class="col-md-2 responsive-logo">
                        <a href={{route('home')}} class="logo"><img src={{asset("/ui/images/logo.png")}} /></a>
                    </div>
                    <div class="col-md-10 responsive-menu">
                        <div id="menuBtn" class="">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <ul class="menu-list">
                            <li class="{{ $active == 'home' ? 'active' : '' }}">
                                <a href={{route("home")}}><i>&#xf015;</i>{{trans('app.home')}}</a>
                            </li>
                            <li class="{{ $active == 'about' ? 'active' : '' }}">
                                <a href={{route('about')}}><i>&#xf0b1;</i>about us</a>
                            </li>
                            <li class="{{ $active == 'property' ? 'active' : '' }}">
                                <a href="#"><i>&#xf1ad;</i>Properties</a>
                                <ul>
                                    <li>
                                        <a href={{route('search')}}>View All Properties</a>
                                    </li>
                                    <li><a href={{url('search/2')}}>Properties for Rent </a></li>
                                    <li><a href={{url('search/1')}}>Properties for Sale </a></li>
                                    <li><a href={{url('search/3')}}>Properties for Rent & Sale </a></li>
                                    <li><a href={{route('category-property')}}>Type of Properties </a></li>
                                    <li>
                                        <a href={{route('category-property')}}>All Categories</a>
                                        <ul>
                                            @php
                                                $propertyTypes = (new \App\Services\PropertyService)->propertyType();
                                            @endphp
                                                @foreach ($propertyTypes as $propertyType)
                                                    <li><a href={{url('search/type/'.$propertyType->id)}}>{{$propertyType->type_name}}</a></li>
                                                @endforeach


                                        </ul>
                                    </li>
                                    <li><a href={{route('destinations')}}>Destinations</a></li>
                                </ul>
                            </li>
                            <li class="{{ $active == 'blog' ? 'active' : '' }}">
                                <a href={{route('blog')}}><i>&#xf02d;</i>blog</a>
                            </li>
                            <li class="{{ $active == 'faq' ? 'active' : '' }}">
                                <a href={{url('faq/0')}}><i>&#xf27a;</i>faq</a>
                            </li>
                            <li class="{{ $active == 'contact' ? 'active' : '' }}">
                                <a href={{route('contact')}}><i>&#xf2b9;</i>contact</a>
                            </li>
                            <li>
                                <a href={{route('destinations')}}>destinations</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->
@yield('content')
<!-- Footer Start -->
    <footer>
        <div class="footer-main-banner">
            <div class="main-container-wrapper">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <a href={{route('home')}} class="footer-logo"><img
                                    src={{asset("/ui/images/footter-logo.png")}} alt="logo"></a>
                        <ul class="footer-menu-list">
                            <li>
                                <p>In 1986 we got to know by chance and learnt to love Tuscany. In the search for new
                                    houses and flats for you</p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <ul class="footer-menu-list">
                            <li>
                                <span>Quick Links</span>
                            </li>
                            <li>
                                <span><a href={{route('about')}}>About Us</a></span>
                            </li>
                            <li>
                                <span><a href={{route('search')}}>Properties</a></span>
                            </li>
                            <li>
                                <span><a href={{route('destinations')}}>Destinations</a></span>
                            </li>
                            <li>
                                <span><a href="#">New Arrival</a></span>
                            </li>
                            <li>
                                <span><a href="#">Special offer Page</a></span>
                            </li>
                            <li>
                                <span><a href="/myfavourite">Your Favorite Properties</a>({{(new \App\Services\PropertyService)->getFavCount() }})</span>
                            </li>
                            <li>
                                <span><a href={{route('blog')}}>Blog</a></span>
                            </li>
                            <li>
                                <span><a href={{route('faq')}}>FAQ</a></span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <ul class="footer-menu-list">
                            <li>
                                <span>Registred office:</span>
                            </li>
                            <li>
                                <span>Schömerweg 14 94050 Pocking/Germany</span>
                            </li>
                            <li>
                                <span class="pt12"><a href="#">Tel.: +49 08538 2659988</a></span>
                            </li>
                            <li>
                                <span class="pt12"><a href="#">Fax: +49 0821 9998501223</a></span>
                            </li>
                            <li>
                                <span class="pt12"><a href="#">info@italica.de</a></span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <ul class="footer-menu-list">
                            <li>
                                <span>Service Office Italy:</span>
                            </li>
                            <li>
                                <span>via degli Olmi 31 54100 Massa/Italy</span>
                            </li>
                            <li>
                                <span class="pt12"><a href="#">Tel.: +39 0585 807818</a></span>
                            </li>
                            <li>
                                <span class="pt12"><a href="#">Fax: +39 0585 807 818</a></span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-2 col-sm-12">
                        <ul class="social-media-link">
                            <li>
                                <span>Get in touch with us</span>
                            </li>
                            <li><a href="https://www.facebook.com/italicahomes/">&#xf082;</a></li>
                            <li><a href="#">&#xf16d;</a></li>
                            <li><a href="https://twitter.com/livingartIT">&#xf081;</a></li>
                            <li><a href="https://www.facebook.com/italicahomes/">&#xf0d4;</a></li>
                            <li><a href="#">&#xf08c;</a></li>
                            <li><a href="#">&#xf167;</a></li>
                            <li><a href="#">&#xf17e;</a></li>
                        </ul>
                    </div>
                </div>
                <div class="wrapper">
                    <ul class="footer-menu-home-list">
                        <li>
                            <a href="#">Privacy Policy</a>
                        </li>
                        <li>
                            <a href={{route('terms')}}>Terms Of Use</a>
                        </li>
                        <li>
                            <a href={{route('legal')}}>Legal Notice</a>
                        </li>
                        <li>
                            <a href={{route('contact')}}>Contact Us</a>
                        </li>
                        <li>
                            <a href="#">Sitemap</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="main-copy-right-block">
            <div class="main-container-wrapper">
                <div class="row">
                    <div class="col-md-12">
                        <span class="copy-right-text">Copyright &copy; 2018 Italica Homes. All Rights Reserved.</span>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->
</div>
@yield('custom-js')
</body>
</html>
