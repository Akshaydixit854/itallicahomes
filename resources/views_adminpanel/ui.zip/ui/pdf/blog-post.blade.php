<h1>{{$post->title}}</h1>
<h3>Published at: {{$post->updated_at}}</h3>
<p>{{$post->content}}</p>