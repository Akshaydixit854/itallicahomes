@extends('ui.layouts.app')

@section('custom-css')
    <link rel="icon" href={{asset("ui/images/favicon.png")}} sizes="16x16" type="image/png">
    <!-- Bootstrap CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/bootstrap.min.css")}}>
    <!-- Bootstrap CSS End -->
    <!-- Custom CSS Start -->
    <link rel="stylesheet" href={{asset("ui/css/styles.css")}}>
    <link rel="stylesheet" href={{asset("ui/css/responsive.css")}}>
    <!-- Custom CSS End -->
@endsection
@if(Session::has('message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
@endif

@section('content')
    <!-- Banner Section Start -->
    <div class="wrapper">
        <div class="about-page-banner">
            <img src={{asset("ui/images/destination_banner.jpg")}} alt="banner"/>
        </div>
    </div>
    <!-- Banner Section End -->
    <!-- FAQ Start -->
    <div class="wrapper">
        <div class="about-us-text-wrapper remove-box-shadow">
            <div class="main-container-wrapper">
                <span class="main-heading">New Arrivals</span>
                <div class="wrapper">
                    <div class="row">
                        @foreach($properties as $property)
                            <div class="col-md-4">
                                <div class="properties-list-wrapper equal-height">
                                    <div class="properties-pic-section">
                                        <span><img src={{asset("/images/cover-images/".$property->cover_image_name)}}></span>
                                        <ul class="properties-list">
                                            <li>
                                                <span>{{$property->beds}}</span>
                                                <abbr>Beds</abbr>
                                                <em>&#xf236;</em>
                                            </li>
                                            <li>
                                                <span>{{$property->baths}}</span>
                                                <abbr>Baths</abbr>
                                                <em>&#xf2cd;</em>
                                            </li>
                                            <li>
                                                <span>1</span>
                                                <abbr>Kitchen</abbr>
                                                <em>&#xf0f5;</em>
                                            </li>
                                        </ul>
                                        <abbr class="red-tag" style="background: {{$property->type->ui_color}}">{{$property->type->type_name}}</abbr>
                                    </div>
                                    <div class="properties-name">
                                        <span><em>{{(new \App\Services\PropertyService)->truncate($property->name) }}</em><i><a href="/favourite/{{$property->id}}">{{(new \App\Services\PropertyService)->checkFav($property->id) }}</a></i></span>
                                        <abbr class="properties-loction"><em>&#xf041;</em>{{(new \App\Services\PropertyService)->getRegion($property->region_id) }}</abbr>
                                        <i class="properties-price-doller">{{$property->price}}</i>
                                    </div>
                                    <div class="properties-decription">
                                        {{(new \App\Services\PropertyService)->truncate($property->short_description,250) }}
                                    </div>
                                    <a href="/properties/{{$property->id}}" class="properties-link">Read More</a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="properties-view-all">
                        <a href="/search">View All</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FAQ Start End -->
@endsection


@section('custom-js')
    <!-- Bootstrap JS Start -->
    <script src={{asset("ui/js/jquery-library.js")}}></script>
    <script src={{asset("ui/js/popper.min.js")}}></script>
    <script src={{asset("ui/js/bootstrap.min.js")}}></script>
    <script>
        // Responsive Menu  Start
        $(document).on('ready', function () {
            $(".menu-list li ul").before("<i class='sub-menu-icon'> &#xf0dd; </i>");
            $('#menuBtn').click(function () {
                $('#menuBtn').toggleClass('open');
                $('.menu-list').toggleClass('menuvisible');
            });
            $(".menu-list li i").click(function (e) {
                $(this).next("ul").slideToggle();
            });

            $('#js-contact-us').click(function(){
                if($('.error').length > 0){
                    $('.error').remove();
                }
                var name = $('.name').val();
                var email = $('.email').val();
                var question = $('.question').val();
                if(name.trim() == '' || email.trim() == '' || question.trim() == ''){
                    if(name.trim() == ''){
                        $('.name').after('<p class="error">Required</p>');
                    }
                    if(email.trim() == ''){
                        $('.email').after('<p class="error">Required</p>');
                    }
                    if(question.trim() == ''){
                        $('.question').after('<p class="error">Required</p>');
                    }
                    return false;
                }
                if(!validateEmail(email)){
                    $('.email').after('<p class="error">Invalid email</p>');
                    return false;
                }
            });


        });
        // Responsive Menu  Start
    </script>
@endsection
