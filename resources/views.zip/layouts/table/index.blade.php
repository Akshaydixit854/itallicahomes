@extends('index')

@section('title')

@endsection

@section('extra-css')

@endsection

@section('content')

@endsection

@section('extra-script')

@endsection